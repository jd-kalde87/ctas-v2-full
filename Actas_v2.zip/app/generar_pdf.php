<?php
// app/generar_pdf.php
// Esta vista no necesita mostrar nada, 
// ya que el módulo JS se encarga de todo en segundo plano.
?>