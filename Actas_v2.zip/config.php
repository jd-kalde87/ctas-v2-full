<?php
// Durante el desarrollo, apuntamos a nuestro nuevo backend local que corre en el puerto 3000
define('BACKEND_API_URL', 'http://localhost:3000/');
?>